import java.io.*;
import java.util.*;
import java.text.SimpleDateFormat;
class MedicalStore
{
final static int S_Reg_No=1212;
final static String S_Name="SHRI GURU";
final static String S_Add="Shivaji Nager,Amravati.";
final static String O_Name="Nilesh Rathod";
long S_Tel_No=95229900;
public void MS_Out()				//Medical store information
{
System.out.println("");
System.out.println("----------------------------------------------------------------------------------------------------------------");
System.out.println("\t\t\t\t\tWELCOME TO MEDICAL STORE");
System.out.println("----------------------------------------------------------------------------------------------------------------");
System.out.println("");
System.out.println("\t\t\t\t\tMEDICAL STORE INFORMATION");
System.out.println("");
System.out.println("\tMedical Store Registered Number  :-\t"+S_Reg_No);
System.out.println("\tMedical Store Name               :-\t"+S_Name);
System.out.println("\tMedical Owner Name               :-\t"+O_Name);
System.out.println("\tMedical Store Address            :-\t"+S_Add);
System.out.println("\tMedical Store Telephone Number   :-\t"+S_Tel_No);
System.out.println("");
System.out.println("");
System.out.println("----------------------------------------------------------------------------------------------------------------");
}
}
class Medicine extends MedicalStore
{
public int mid[]=new int[10]; 
int i;
public String M_Name;
public float P_Price;
public float S_Price;
public String D_Cat;
public String U_Meas;
public void  M_input()throws Exception				    //Medicine Stock
		{
	
		DataInputStream d1=new DataInputStream(System.in);
		System.out.println("Please input the Medicine Name");
		M_Name=d1.readLine();
		System.out.println("Please input the Medicine Unit of Measurement");
		U_Meas=d1.readLine();
		System.out.println("Please input the Durg Category");
		D_Cat=d1.readLine();
		System.out.println("Please input the Purchase Price");
		P_Price=Float.parseFloat(d1.readLine());
		System.out.println("Please input the Selling Price");
		S_Price=Float.parseFloat(d1.readLine());	
		}
		}
class Customer  extends Medicine						//Customer Information
{
int i;
public int cid[]=new int[10];
public String C_Add;
public String C_Name;
public int C_Pin;
public int C_Tel_No;

public void C_input() throws Exception					//Customer Info input
{
DataInputStream d2=new DataInputStream(System.in);
System.out.println("");	
System.out.println("");
System.out.println("Please input the Customer Name");
C_Name=d2.readLine();
System.out.println("Please input the Customer Address");
C_Add=d2.readLine();
System.out.println("Please input the Customer Pin Code No.");
C_Pin=Integer.parseInt(d2.readLine());
System.out.println("Please input the Customer Telephone No.");
C_Tel_No=Integer.parseInt(d2.readLine());
}
}
class Doctor 	extends Customer	//Doctor Information
{
public int i;
public int did[]=new int[10]; 
public String D_Name;
public String Qal;
public String D_Add;
public String Clinic;
public int Mob_no;
public void D_input() throws Exception				//Doctor info Input
{
DataInputStream d3=new DataInputStream(System.in);
System.out.println("Please input the Doctor Name");
D_Name=d3.readLine();
System.out.println("Please input the Qualification");
Qal=d3.readLine();
System.out.println("Please input the Doctor Address");
D_Add=d3.readLine();
System.out.println("Please input the Clinic Address");
Clinic=d3.readLine();
System.out.println("Please input the Doctor Mobile No.");
Mob_no=Integer.parseInt(d3.readLine());
System.out.println("\n");
}
}
class Billing extends Doctor			//Billing
{
int i;
int B_no;
float total;
int id1,id2,pn;
public int loc=-1;
public void bill()
{
System.out.println("");
System.out.println("");
System.out.println("---------------------------------------------------------------------------------------------------------------");
System.out.println("\t\t\t\t\tBILLING");
System.out.println("---------------------------------------------------------------------------------------------------------------");
System.out.println("");
System.out.println("  Reg. No. :- "+S_Reg_No);
System.out.println("  Store Name :- "+S_Name);
System.out.println("  Address  :- "+S_Add);
System.out.println("  Telephone No:- "+S_Tel_No);
SimpleDateFormat cdt = new SimpleDateFormat("yyyy/MM/dd");
cdt.setCalendar(Calendar.getInstance(TimeZone.getTimeZone("GMT")));
System.out.println("\n Date:\t"+cdt.format(System.currentTimeMillis()));
System.out.println("");
System.out.println("");
}
}
class A extends Billing
{
public static void main(String args[])throws Exception
{
char choice;
Console console = System.console();
DataInputStream d4=new DataInputStream(System.in);
int ch,i,loc=-1;
double bill=0; 
A m =new A();
m.MS_Out();
int l1,l2,l3;
Billing bb=new Billing();
Medicine[] M = new Medicine[3];
for(i=0;i<3;i++)
{
M[i] =  new Medicine();  
l1 = M.length;
M[i].mid[i] = l1-(2-i);
}
Doctor[] D = new Doctor[3];
for(i=0;i<3;i++)
{
D[i] =  new Doctor();
l3 = M.length;
D[i].did[i] = l3-(2-i);
}
Customer[] C = new Customer[3];
for(i=0;i<3;i++)
{
C[i] =  new Customer(); 
l2 = M.length;
C[i].cid[i] = l2-(2-i);  
System.out.println("");
}
do
{
System.out.println("1. Input the Medicine");
System.out.println("2. Input the customer Information");
System.out.println("3. Input the Doctor Information");
System.out.println("4. Billing");
System.out.println("");
System.out.println("Please Input the your Choise");
ch=Integer.parseInt(d4.readLine());
switch(ch)
{
case 1:
for(i=0;i<3;i++)
{
System.out.println("");
System.out.println("---------------------------------------------------------------------------------------------------------------");
System.out.println("");
System.out.println("\t\t\t\t\tMEDICINE INFO INPUT");
System.out.println("");
System.out.println("");	
System.out.println("\nMedicine id    :" +M[i].mid[i]);
M[i].M_input();
}
break;
case 2:
System.out.println("");
System.out.println("---------------------------------------------------------------------------------------------------------------");
System.out.println("");
System.out.println("\t\t\t\t\tCUSTOMER INFO INPUT");
System.out.println("");
System.out.println("");	
for(i=0;i<2;i++)
{
System.out.println("");
System.out.println("Customer id   :" +C[i].cid[i]);
C[i].C_input();
}
break;	
case 3:
System.out.println("");
System.out.println("---------------------------------------------------------------------------------------------------------------");
System.out.println("");
System.out.println("\t\t\t\t\tDOCTOR INFO INPUT");
System.out.println("");
for(i=0;i<2;i++)
{
System.out.println("\nDoctor id    :" +D[i].did[i]);
D[i].D_input();
}
case 4:
int Qty;
System.out.println("");
System.out.println("please input the customer id ");         
DataInputStream d8= new DataInputStream(System.in);
int Cid=Integer.parseInt(d8.readLine());   

DataInputStream d7= new DataInputStream(System.in);
System.out.println("");
System.out.println("");
System.out.println("input the medicine id");
int Mid=Integer.parseInt(d7.readLine());
System.out.println("");
System.out.println("Please input the Medicine Qty");
Qty=Integer.parseInt(d7.readLine());
System.out.println("");
				
				bb.bill();
				for(i=0;i<2;i++)
				{
				if(Cid==C[i].cid[i]) 		
				{
				loc=i;
				break;
				}
		       		}
				if(loc!=-1)
				{
				for(i=0;i<3;i++)
				{
				if(Cid==C[i].cid[i])
				{
				if(loc!=-1)
				{
				System.out.println(""+C[i].C_Name);
				System.out.println(""+C[i].C_Add);
				System.out.println(""+C[i].C_Tel_No);
				System.out.println("");
				System.out.println(""); 
				}}}}
				else
 				{
				System.out.println("NOT FOUND");
 				}

				for(i=0;i<2;i++)
				{
				if(Mid==M[i].mid[i]) 		
				{
				loc=i;
				break;
				}
		       		}
				if(loc!=-1)
				{
				for(i=0;i<3;i++)
				{
				if(Mid==M[i].mid[i])
				{
				if(loc!=-1)
				{
				System.out.println("\t-----------------------------------------------------------------------");
				System.out.println("\t|  Medicine Name"+"\tUnit of Measurement"+"\tDurg Category"+"\tPrice |");
				System.out.println("\t|---------------------------------------------------------------------|");
				System.out.println("\t|  "+M[i].M_Name +"\t\t\t"+M[i].U_Meas +"\t\t\t"+M[i].D_Cat +"\t\t"+M[i].S_Price +"   |");	
				System.out.println("\t|\t\t\t\t\t\t\t\t      |");
				System.out.println("\t-----------------------------------------------------------------------");
				}

					for(i=0;i<1;i++)
					{
					bill=M[i].S_Price*Qty;
					System.out.println("\t|\t\t\t\t\t\tTotal Bill :-"+ bill+"      |");
					System.out.println("\t-----------------------------------------------------------------------");
					System.out.println("\t|\t\t\t\t\tPrescribed by  "+D[i].D_Name +"           |");
					System.out.println("\t-----------------------------------------------------------------------");
					break;
					}
					System.out.println("");
					System.out.println("");
					System.out.println("\t\t\t\t\t****** THANK YOU FOR PURCHASE A MEDICINES ********");	
					System.out.println("");
					System.out.println("");
					break;	
					}
					}
					}
					else
					{
					System.out.println("");
					}
					System.out.println("");
					System.out.println("\n"+O_Name);	
						break;
default:
System.out.println("Wrong input");
break;
}
 choice = console.readLine("\n Do You Want To Continue (Y/N)?: ").charAt(0);
        }         
        while((choice!='n')&&(choice!='N'));
}
}
